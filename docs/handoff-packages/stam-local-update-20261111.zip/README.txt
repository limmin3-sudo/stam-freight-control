STAM 로컬 이어가기 — 2026-11-11

이 ZIP은 최신 변경 파일 묶음입니다. 전체 저장소가 아니며 source 폴더만 실행할 수 없습니다.
기준 커밋: 50272b880242d4eeabd610b78dc7b963e4e3b6e4
브랜치: handoff/local-studio-20261110
저장소: https://github.com/limmin3-sudo/stam-freight-control.git
현재 커밋/푸시/배포 없음. git pull만으로 이 ZIP의 변경을 받을 수 없습니다.

로컬 Codex에게 이 ZIP/압축 해제 폴더를 주고 아래 작업을 요청하세요.
1. 새 이력 저장소의 깨끗한 기준 커밋 사본을 준비합니다. 기존 수정이 있는 폴더나 폐기한 옛 저장소에는 덮어쓰지 않습니다.
   git clone --branch handoff/local-studio-20261110 --single-branch https://github.com/limmin3-sudo/stam-freight-control.git stam-local-20261111
   cd stam-local-20261111
   git switch --detach 50272b880242d4eeabd610b78dc7b963e4e3b6e4
   git switch -c local/continue-20261111
   폴더/브랜치가 이미 있으면 새 이름을 사용합니다. reset/clean/강제 checkout은 하지 않습니다.
2. manifest.json의 각 파일에 대해 source 파일 sha256을 검증합니다. modified 대상의 기존 파일은 baseSha256과 같아야 하고 added 경로는 아직 없어야 합니다. 모두 검사한 뒤 source의 상대 경로대로 저장소에 복사합니다. 삭제 목록도 확인합니다(현재 0개).
3. git diff --check와 git status로 변경을 확인합니다. tracked.patch는 기존 파일의 변경 검토용이며 source 복사와 중복 적용하지 않습니다.
4. AGENTS.md, PROJECT_STATUS.md 최상단, docs/LOCAL-CODEX-HANDOFF.md 최상단, docs/CONSOLE-TRAVEL-PRODUCTION.md를 읽습니다. 아래쪽 과거 기록보다 최상단 인계를 우선합니다.
5. Node 22.12 이상에서 start-control-room-preview.cmd를 실행합니다. 또는 npm ci --prefix apps/control-room 후 npm run dev:control-room.
   미리보기: http://127.0.0.1:5173/#/bridge?lang=ko

영상: 로컬 Gen Studio 연결/최근 결과/모델/시작·끝 프레임 지원부터 확인하세요. Runway 사용/외부 업로드 승인 요청은 종료됐습니다. 승인한 모니터 화면을 다시 제작하지 말고 왼쪽 진입 영상 하나부터 이어갑니다.
시작: docs/handoff-media/2026-11-11/bridge-video-start.png
도착: apps/control-room/src/assets/console-screen-only.png
검증: 직전 최종 빌드 성공, 관제실 10개 테스트 파일, 전체 232개 테스트 통과, PC/모바일 브라우저 확인. 이번 인계는 문서와 자료만 정리했습니다.
미완료: 이동 영상/재생 연결, 실제 운항 진행 연동, 상세 파트너 대화.

Git 이력·계정·환경 변수·node_modules·개인 게임 로그·브라우저 데이터는 포함하지 않습니다. 반려 시안은 비교용 보존 자료이며 런타임에 사용하지 않습니다. 커밋/푸시/배포는 별도 승인 전 실행하지 않습니다.
