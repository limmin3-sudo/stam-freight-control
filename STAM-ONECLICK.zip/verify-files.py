"""Verify the binary and text files after applying the STAM handoff patch."""
from hashlib import sha256
import json
from pathlib import Path
import sys

manifest = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
root = Path(sys.argv[2]).resolve()
errors = []
for entry in manifest["files"]:
    path = root / entry["path"]
    if entry["status"] == "D":
        if path.exists():
            errors.append(f"expected deletion: {entry['path']}")
    elif not path.is_file():
        errors.append(f"missing: {entry['path']}")
    elif sha256(path.read_bytes()).hexdigest() != entry["sha256"]:
        errors.append(f"content differs: {entry['path']}")
if errors:
    sys.exit("\n".join(errors))
print(f"Verified {len(manifest['files'])} paths against the handoff.")
