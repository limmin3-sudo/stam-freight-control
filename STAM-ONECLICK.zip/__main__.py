"""Entry point for the STAM function-team handoff ZIP: python3 <archive>.zip."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile

REPO = Path("/workspace/stam-freight-control-fresh-20261108")
BASE = "1fdce17a94ce8b078a38690541fe05eb9844aa34"
TREE = "2af83903faa94fefd342c9b69f370d320790480e"
BRANCH = "integration/web-cinematics-ready-20261118"
WORK = REPO / ".stam-worktrees" / BRANCH.split("/")[-1]


def git(cwd, *args, data=None):
    return subprocess.run(["git", "-C", str(cwd), *args], input=data,
                          stdout=subprocess.PIPE, check=True).stdout.decode().strip()


def run():
    if not REPO.is_dir() or Path(git(REPO, "rev-parse", "--show-toplevel")).resolve() != REPO.resolve():
        sys.exit(f"STAM 새 이력 사본이 필요합니다: {REPO}")
    with ZipFile(sys.argv[0]) as archive:
        manifest = json.loads(archive.read("files.json"))
        checks = archive.read("SHA256SUMS").decode().splitlines()
        for row in checks:
            digest, name = row.split("  ", 1)
            if hashlib.sha256(archive.read(name)).hexdigest() != digest:
                sys.exit(f"인계 파일 체크섬 오류: {name}")
        patch = archive.read("cinematics.patch")
    if (manifest["base"], manifest["resultTree"]) != (BASE, TREE):
        sys.exit("인계 기준과 파일 목록이 일치하지 않습니다.")
    available = subprocess.run(["git", "-C", str(REPO), "cat-file", "-e", BASE + "^{commit}"],
                               stderr=subprocess.DEVNULL)
    if available.returncode:
        git(REPO, "fetch", "origin", "main")
        git(REPO, "cat-file", "-e", BASE + "^{commit}")
    if not WORK.exists():
        WORK.parent.mkdir(exist_ok=True)
        ignore = WORK.parent / ".gitignore"
        if not ignore.exists():
            ignore.write_text("*\n", encoding="utf-8")
        git(REPO, "worktree", "add", "--quiet", "-b", BRANCH, str(WORK), BASE)
    if (Path(git(WORK, "rev-parse", "--show-toplevel")).resolve() != WORK.resolve()
            or git(WORK, "branch", "--show-current") != BRANCH):
        sys.exit(f"기존 작업 공간의 경로 또는 브랜치가 다릅니다: {WORK}")
    if git(WORK, "write-tree") != TREE:
        if git(WORK, "rev-parse", "HEAD") != BASE or git(WORK, "status", "--porcelain"):
            sys.exit(f"이미 작업 중인 통합본입니다. 변경 사항을 보존했습니다: {WORK}")
        git(WORK, "apply", "--index", "--check", "-", data=patch)
        git(WORK, "apply", "--index", "-", data=patch)
    if git(WORK, "write-tree") != TREE:
        sys.exit("인계 결과 Git 트리가 일치하지 않습니다.")
    for item in manifest["files"]:
        path = WORK / item["path"]
        if item["status"] == "D":
            ok = not path.exists()
        else:
            ok = path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == item["sha256"]
        if not ok:
            sys.exit(f"작업본 내용이 인계본과 다릅니다. 해당 파일을 보존했습니다: {path}")
    print(f"인계 적용·검증 완료 ({len(manifest['files'])}개 경로)\n작업 위치: {WORK}\n브랜치: {BRANCH}")
    print("기능 연결표: docs/cinematics/function-handoff-20261118/HANDOFF.md")


if __name__ == "__main__":
    run()
